# Prompt Registry

每个 Prompt 使用独立版本：
`career.analyze.v1.md`

必须定义：
- Purpose
- Input schema
- Output schema
- System instruction
- Safety constraints
- Evaluation dataset
