# TASK-001 Repository Bootstrap

## Goal
建立项目基础工程。

## Steps
1. 检查当前仓库是否已有项目。
2. 若为空，初始化 pnpm workspace。
3. 建立 apps/api、apps/miniapp、apps/admin、packages/types、packages/domain、packages/ai。
4. 配置 TypeScript strict。
5. 配置 lint / format。
6. 添加基础 README。
7. 不实现业务功能。

## Acceptance Criteria
- package install 成功
- typecheck 成功
- lint 成功
- build 成功
- workspace 结构清晰
